</div>

<?php require_once("../sections/auth_footer.php") ?>

</body>

</html>
